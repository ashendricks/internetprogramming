var User = require('../models/user');

module.exports = function(router) {
	
	// https://localhose:8080/api/users
	router.post('/users',function(req,res){
		var user = new User();

		user.email = req.body.email;
		user.username = req.body.username;
		user.password = req.body.password;
		
		user.save()
		res.send("user created");
	});
	return router;
};


