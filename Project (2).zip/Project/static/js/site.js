var app=angular.module("siteApp",[]);
app.controller('contentCtrl', function($scope,$http,$window, $sce){
	$scope.contact = '<h2>Contact Us</h2>' +'<form>' + '<table style="height: 600px; padding: 20px;">' +'<tr>' +'<td><label for="fname">First Name: </label></td>' +
								'<td><input id="fname" type="text" /></td>' +
								'<td><label for="lname">Last Name: </label></td>' +
								'<td><input id="lname" type="text" /></td>' +
							'</tr><tr>' +
								'<td><label for="email">Email: </label></td>' +
								'<td colspan="3"><input style="width: 100%;" id="email"  type="text" /></td>' +
							'</tr>'+
							'<tr>'+
								'<td><label for="subject">Subject: </label></td>' +
								'<td colspan="3"><input style="width: 100%;" id="subject"  type="text" /></td>' +
							'</tr>' +
							'<tr>' +
								'<td height="400px" colspan="4"><textarea id="message" style="width: 100%; height: 100%;resize: none; "></textarea></td>' +
							'</tr>' +
						'</table>' +
					'</form>' +
					'<button id="send" class="btn btn-primary" style="display: block">Send</button>';
		
	$scope.index = '<div class="col-sm-8">' +
					'<h2 class="red">TUMC</h2>' + 
					'<p>Feb. 4, 2018 – Morning Worship Web Stream Available at the link below – LIVE NOW</p>' +

					'<p><b>Sunday Services are Available via the Internet and Radio</b></p>' +

					'<p>Morning Worship Service:   11:00 am every Sunday</p>' +

					'<p><b>Watch live at</b></p>' + 

					'<p><a href="#">http://www.citylinktv.com/channel/tennille-united-methodist-church/</a></p>' +

					'<p><b>Listen live on the Radio:   WSNT AM 1490</b></p>' +
					
					'<img class="center" src="../images/img.jpg"/>' +
				'</div>';	
		
	$scope.getContact = function() {
               return $sce.trustAsHtml($scope.contact);
             };
	$scope.getIndex = function() {
               return $sce.trustAsHtml($scope.index);
             };
	
})


function submitContact(){
	
	
}

