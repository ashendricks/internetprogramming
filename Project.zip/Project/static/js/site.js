var app=angular.module("siteApp",[]);
app.controller('contentCtrl', function($scope,$http,$window, $sce){
	$scope.content = '<h2>Contact Us</h2>' +'<form>' + '<table style="height: 600px; padding: 20px;">' +'<tr>' +'<td><label for="fname">First Name: </label></td>' +
								'<td><input id="fname" type="text" /></td>' +
								'<td><label for="lname">Last Name: </label></td>' +
								'<td><input id="lname" type="text" /></td>' +
							'</tr><tr>' +
								'<td><label for="email">Email: </label></td>' +
								'<td colspan="3"><input style="width: 100%;" id="email"  type="text" /></td>' +
							'</tr>'+
							'<tr>'+
								'<td><label for="subject">Subject: </label></td>' +
								'<td colspan="3"><input style="width: 100%;" id="subject"  type="text" /></td>' +
							'</tr>' +
							'<tr>' +
								'<td height="400px" colspan="4"><textarea id="message" style="width: 100%; height: 100%;resize: none; "></textarea></td>' +
							'</tr>' +
						'</table>' +
					'</form>' +
					'<button id="send" class="btn btn-primary" style="display: block">Send</button>';
		
	 $scope.deliberatelyTrustDangerousSnippet = function() {
               return $sce.trustAsHtml($scope.content);
             };
	
})


function submitContact(){
	
	
}

