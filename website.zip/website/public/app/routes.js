angular.module('appRoutes',['ngRoute'])
.config(function($routeProvider){
	$routeProvider

	.when('/home',{
		templateUrl: 'app/views/pages/home.html'
	})

	.when('/contact',{
		templateUrl: 'app/views/pages/contact.html'
	})

	.when('/history',{
		templateUrl: 'app/views/pages/history.html'
	})

	.when('/newsletter',{
		templateUrl: 'app/views/pages/newsletter.html'
	})

	.when('/sermons',{
		templateUrl: 'app/views/pages/sermons.html'
	})


	.when('/register',{
		templateUrl: 'app/views/pages/users/register.html',
		controller: 'regCtrl',
		controllerAs: 'register'
	});








	console.log("routes work");
})